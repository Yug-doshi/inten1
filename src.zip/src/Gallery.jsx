import React from 'react'

function Gallery() {
  return (
    <>
      {/* header section start */}
      <div className="header_section">
        {/* ... (remaining header code) */}
      </div>
      {/* header section end */}
      
      {/* gallery section start */}
      <div className="gallery_section layout_padding">
        {/* ... (remaining gallery code) */}
      </div>
      {/* gallery section end */}
      
      {/* footer section start */}
      <div className="footer_section layout_padding">
        {/* ... (remaining footer code) */}
      </div>
      {/* footer section end */}
      
      {/* copyright section start */}
      <div className="copyright_section">
        {/* ... (remaining copyright code) */}
      </div>
      {/* copyright section end */}
      
      {/* Javascript files */}
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      {/* sidebar */}
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
    </>
  )
}

export default Gallery