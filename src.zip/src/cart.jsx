import React from 'react'

function cart(data) {
   const setcart = (args) => data.setcart(args);
   const cart = data.cart;
    {console.log(cart)}
    console.log(setcart);
  return (
    <div>gfdhre</div>
  )
}

export default cart